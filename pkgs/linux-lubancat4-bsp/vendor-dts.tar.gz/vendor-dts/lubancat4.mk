# LubanCat-4 device trees, registered by PKGBUILD prepare().
# -@ on the three board base .dtb: /boot/bsp/overlays/*.dtbo are applied at runtime,
# which needs the base .dtb to carry a /__symbols__ table.
dtb-$(CONFIG_ARCH_ROCKCHIP) += rk3588s-lubancat-4-v1.dtb
dtb-$(CONFIG_ARCH_ROCKCHIP) += rk3588s-lubancat-4.dtb
dtb-$(CONFIG_ARCH_ROCKCHIP) += rk3588s-lubancat-4io.dtb
DTC_FLAGS_rk3588s-lubancat-4-v1 := -@
DTC_FLAGS_rk3588s-lubancat-4 := -@
DTC_FLAGS_rk3588s-lubancat-4io := -@

dtbo-$(CONFIG_ARCH_ROCKCHIP) += \
  rk3588s-lubancat-4-cam0-gc08a8-3264x2448-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam0-gc2053-1920x1080-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam0-gc4653-2560x1440-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam0-imx415-1920x1080-60fps-overlay.dtbo \
  rk3588s-lubancat-4-cam0-imx415-3840x2160-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam0-ov8858-1632x1224-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam0-ov8858-3264x2448-15fps-overlay.dtbo \
  rk3588s-lubancat-4-cam1-gc08a8-3264x2448-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam1-gc2053-1920x1080-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam1-gc4653-2560x1440-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam1-imx415-1920x1080-60fps-overlay.dtbo \
  rk3588s-lubancat-4-cam1-imx415-3840x2160-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam1-ov8858-1632x1224-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam1-ov8858-3264x2448-15fps-overlay.dtbo \
  rk3588s-lubancat-4-cam2-gc08a8-3264x2448-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam2-gc2053-1920x1080-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam2-gc4653-2560x1440-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam2-imx415-1920x1080-60fps-overlay.dtbo \
  rk3588s-lubancat-4-cam2-imx415-3840x2160-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam2-ov8858-1632x1224-30fps-overlay.dtbo \
  rk3588s-lubancat-4-cam2-ov8858-3264x2448-15fps-overlay.dtbo \
  rk3588s-lubancat-4-dsi0-vp2-1024x600-7inch-ebf410173-overlay.dtbo \
  rk3588s-lubancat-4-dsi0-vp2-1080x1920-5.5inch-ebf410125-overlay.dtbo \
  rk3588s-lubancat-4-dsi0-vp2-800x1280-10.1inch-ebf410177-overlay.dtbo \
  rk3588s-lubancat-4-dsi0-vp2-800x1280-10.1inch-s8001280b1060b-overlay.dtbo \
  rk3588s-lubancat-4-dsi0-vp2-generic-overlay.dtbo \
  rk3588s-lubancat-4-dsi1-vp3-1024x600-7inch-ebf410173-overlay.dtbo \
  rk3588s-lubancat-4-dsi1-vp3-1080x1920-5.5inch-ebf410125-overlay.dtbo \
  rk3588s-lubancat-4-dsi1-vp3-800x1280-10.1inch-ebf410177-overlay.dtbo \
  rk3588s-lubancat-4-dsi1-vp3-800x1280-10.1inch-s8001280b1060b-overlay.dtbo \
  rk3588s-lubancat-4-dsi1-vp3-generic-overlay.dtbo \
  rk3588s-lubancat-4-hdmi0-vp0-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi0-vp2-1024x600-7inch-ebf410173-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi0-vp2-1080x1920-5.5inch-ebf410125-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi0-vp2-1200x1920-10.1inch-boe10p1-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi0-vp2-800x1280-10.1inch-ebf410177-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi0-vp2-800x1280-10.1inch-s8001280b1060b-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi0-vp2-generic-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi1-vp3-1024x600-7inch-ebf410173-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi1-vp3-1080x1920-5.5inch-ebf410125-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi1-vp3-1200x1920-10.1inch-boe10p1-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi1-vp3-800x1280-10.1inch-ebf410177-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi1-vp3-800x1280-10.1inch-s8001280b1060b-overlay.dtbo \
  rk3588s-lubancat-4-v1-dsi1-vp3-generic-overlay.dtbo \
  rk3588s-lubancat-4-v1-xl9535-overlay.dtbo \
  rk3588s-lubancat-4-xl9535-overlay.dtbo \
  rk3588s-lubancat-4io-cam0-gc08a8-3264x2448-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam0-gc2053-1920x1080-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam0-gc4653-2560x1440-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam0-imx415-1920x1080-60fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam0-imx415-3840x2160-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam0-ov8858-1632x1224-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam0-ov8858-3264x2448-15fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam1-gc08a8-3264x2448-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam1-gc2053-1920x1080-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam1-gc4653-2560x1440-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam1-imx415-1920x1080-60fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam1-imx415-3840x2160-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam1-ov8858-1632x1224-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam1-ov8858-3264x2448-15fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam2-gc08a8-3264x2448-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam2-gc2053-1920x1080-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam2-gc4653-2560x1440-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam2-imx415-1920x1080-60fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam2-imx415-3840x2160-15fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam2-ov8858-1632x1224-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam2-ov8858-3264x2448-15fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam3-gc08a8-3264x2448-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam3-gc2053-1920x1080-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam3-gc4653-2560x1440-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam3-imx415-1920x1080-60fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam3-imx415-3840x2160-15fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam3-ov8858-1632x1224-30fps-overlay.dtbo \
  rk3588s-lubancat-4io-cam3-ov8858-3264x2448-15fps-overlay.dtbo \
  rk3588s-lubancat-4io-dsi0-vp2-1024x600-7inch-ebf410173-overlay.dtbo \
  rk3588s-lubancat-4io-dsi0-vp2-1080x1920-5.5inch-ebf410125-overlay.dtbo \
  rk3588s-lubancat-4io-dsi0-vp2-800x1280-10.1inch-ebf410177-overlay.dtbo \
  rk3588s-lubancat-4io-dsi0-vp2-800x1280-10.1inch-s8001280b1060b-overlay.dtbo \
  rk3588s-lubancat-4io-dsi0-vp2-generic-overlay.dtbo \
  rk3588s-lubancat-4io-dsi1-vp3-1024x600-7inch-ebf410173-overlay.dtbo \
  rk3588s-lubancat-4io-dsi1-vp3-1080x1920-5.5inch-ebf410125-overlay.dtbo \
  rk3588s-lubancat-4io-dsi1-vp3-800x1280-10.1inch-ebf410177-overlay.dtbo \
  rk3588s-lubancat-4io-dsi1-vp3-800x1280-10.1inch-s8001280b1060b-overlay.dtbo \
  rk3588s-lubancat-4io-dsi1-vp3-generic-overlay.dtbo \
  rk3588s-lubancat-4io-hdmi0-vp0-overlay.dtbo
